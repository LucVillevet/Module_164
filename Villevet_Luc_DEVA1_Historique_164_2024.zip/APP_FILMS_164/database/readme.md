## Module 164 (Luc Villevet)

Pour que ça marche, on a besoin de Laragon en cours d'exécution.

En plus de Laragon, il faut également avoir installé Python.

La première fois, il faut aussi exécuter le fichier "1_ImportationDimpSql.py" dans le dossier "database".

Lorsque "run_mon_app.py" est aussi en cours d'exécution, on peut accéder au site Internet à cette adresse : 
http://127.0.0.3:5554